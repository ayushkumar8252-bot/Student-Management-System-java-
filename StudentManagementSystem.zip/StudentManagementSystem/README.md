# Student Management System (Java)

A beginner-friendly, menu-driven Java console project to manage student records.

## Features
- Add a student
- View all students
- Search by student ID
- Update student details
- Delete a student
- Save records in `students.txt` and load them the next time the program starts
- Basic input validation and duplicate-ID checking

## Requirements
- Java JDK 17 or later
- Terminal / Command Prompt, or an IDE such as IntelliJ IDEA, Eclipse, or VS Code

## How to run

Open a terminal in the project folder and run:

```bash
javac src/*.java
java -cp src Main
```

On Windows, the same commands work in Command Prompt or PowerShell if Java is added to PATH.

## Project structure

```text
StudentManagementSystem/
├── src/
│   ├── Main.java
│   ├── Student.java
│   └── StudentManager.java
├── .gitignore
└── README.md
```

## Concepts used
- Classes and objects
- Encapsulation (private fields and getters/setters)
- ArrayList
- Loops and conditional statements
- Methods
- Exception handling
- File handling

## GitHub upload

1. Create a new repository on GitHub named `StudentManagementSystem`.
2. Extract this project ZIP.
3. Open a terminal inside the extracted `StudentManagementSystem` folder.
4. Run:

```bash
git init
git add .
git commit -m "Add Student Management System Java project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/StudentManagementSystem.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Author
Add your name here.
