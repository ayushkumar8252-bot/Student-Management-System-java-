import java.io.*;
import java.util.ArrayList;

public class StudentManager {
    private final ArrayList<Student> students = new ArrayList<>();
    private static final String FILE_NAME = "students.txt";

    public StudentManager() {
        loadFromFile();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public Student findStudent(int id) {
        for (Student student : students) {
            if (student.getId() == id) return student;
        }
        return null;
    }

    public boolean deleteStudent(int id) {
        Student student = findStudent(id);
        if (student == null) return false;
        students.remove(student);
        return true;
    }

    public void showAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.println("\n--------- STUDENT RECORDS ---------");
        for (Student student : students) System.out.println(student);
        System.out.println("-----------------------------------");
    }

    public void saveToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Student s : students) {
                writer.println(s.getId() + "|" + s.getName().replace("|", " ")
                        + "|" + s.getCourse().replace("|", " ") + "|" + s.getMarks());
            }
        } catch (IOException e) {
            System.out.println("Could not save data: " + e.getMessage());
        }
    }

    private void loadFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|", -1);
                if (parts.length == 4) {
                    try {
                        students.add(new Student(Integer.parseInt(parts[0]), parts[1],
                                parts[2], Double.parseDouble(parts[3])));
                    } catch (NumberFormatException ignored) {
                        System.out.println("Skipping an invalid record in students.txt");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Could not load saved data: " + e.getMessage());
        }
    }
}
