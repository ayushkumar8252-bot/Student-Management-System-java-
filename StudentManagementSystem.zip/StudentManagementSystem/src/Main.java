import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentManager manager = new StudentManager();

    public static void main(String[] args) {
        boolean running = true;
        System.out.println("================================");
        System.out.println("     STUDENT MANAGEMENT SYSTEM");
        System.out.println("================================");

        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> addStudent();
                case 2 -> manager.showAllStudents();
                case 3 -> searchStudent();
                case 4 -> updateStudent();
                case 5 -> deleteStudent();
                case 6 -> {
                    manager.saveToFile();
                    System.out.println("Data saved. Thank you for using the system!");
                    running = false;
                }
                default -> System.out.println("Invalid choice. Please select 1 to 6.");
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n----------- MENU -----------");
        System.out.println("1. Add Student");
        System.out.println("2. View All Students");
        System.out.println("3. Search Student by ID");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("6. Save and Exit");
        System.out.println("----------------------------");
    }

    private static void addStudent() {
        int id = readInt("Enter student ID: ");
        if (manager.findStudent(id) != null) {
            System.out.println("A student with this ID already exists.");
            return;
        }
        System.out.print("Enter student name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter course: ");
        String course = scanner.nextLine().trim();
        double marks = readDouble("Enter marks (0-100): ");

        if (name.isEmpty() || course.isEmpty() || marks < 0 || marks > 100) {
            System.out.println("Invalid details. Name/course cannot be empty and marks must be 0-100.");
            return;
        }
        manager.addStudent(new Student(id, name, course, marks));
        System.out.println("Student added successfully.");
    }

    private static void searchStudent() {
        int id = readInt("Enter student ID to search: ");
        Student student = manager.findStudent(id);
        if (student == null) System.out.println("Student not found.");
        else System.out.println(student);
    }

    private static void updateStudent() {
        int id = readInt("Enter student ID to update: ");
        Student student = manager.findStudent(id);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.print("Enter new name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter new course: ");
        String course = scanner.nextLine().trim();
        double marks = readDouble("Enter new marks (0-100): ");

        if (name.isEmpty() || course.isEmpty() || marks < 0 || marks > 100) {
            System.out.println("Invalid details. Update cancelled.");
            return;
        }
        student.setName(name);
        student.setCourse(course);
        student.setMarks(marks);
        System.out.println("Student updated successfully.");
    }

    private static void deleteStudent() {
        int id = readInt("Enter student ID to delete: ");
        if (manager.deleteStudent(id)) System.out.println("Student deleted successfully.");
        else System.out.println("Student not found.");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
